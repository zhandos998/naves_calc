import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf0f0f0);

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.2, 1000);
camera.position.set(15, 2, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

const light = new THREE.DirectionalLight(0xffffff, 1);
light.position.set(5, 10, 5);
scene.add(light);

scene.add(new THREE.AmbientLight(0x404040));

const metalMaterial = new THREE.MeshStandardMaterial({ color: 0x888888, metalness: 0.7, roughness: 0.3 });
const canopy = new THREE.Group();
scene.add(canopy);

const params = {
    width: 10,
    depth: 4,
    height: 5,
    postThickness: 0.2,
    frameType: "arched",
};

class ArchCurve extends THREE.Curve {
    constructor(startX, endX, height) {
        super();
        this.startX = startX;
        this.endX = endX;
        this.height = height;
    }

    getPoint(t) {
        const x = THREE.MathUtils.lerp(this.startX, this.endX, t);
        const y = this.height + Math.sin(t * Math.PI) * (this.height / 2);
        return new THREE.Vector3(x, y, 0);
    }
}

function createCanopy() {
    canopy.clear();

    const foundation = new THREE.Mesh(
        new THREE.BoxGeometry(params.width + 1, 0.2, params.depth + 1),
        new THREE.MeshStandardMaterial({ color: 0xaaaaaa })
    );
    foundation.position.y = -0.1;
    canopy.add(foundation);

    const numPosts = Math.max(2, Math.ceil(params.width / 2));
    const postGeometry = new THREE.BoxGeometry(params.postThickness, params.height, params.postThickness);

    for (let i = 0; i < numPosts; i++) {
        let x = -params.width / 2 + (i * params.width) / (numPosts - 1);
        [-params.depth / 2, params.depth / 2].forEach(z => {
            const post = new THREE.Mesh(postGeometry, metalMaterial);
            post.position.set(x, params.height / 2, z);
            canopy.add(post);
        });
    }

    const roofSegments = numPosts - 1;
    const beamGeometry = new THREE.BoxGeometry(params.width / roofSegments + 1, 0.2, 0.2);

    for (let i = 0; i < roofSegments; i++) {
        let x = -params.width / 2 + (i * params.width) / roofSegments + params.width / (2 * roofSegments);
        [-params.depth / 2, params.depth / 2].forEach(z => {
            const beam = new THREE.Mesh(beamGeometry, metalMaterial);
            beam.position.set(x, params.height, z);
            canopy.add(beam);
        });
    }

    let roofPoints = [];
    const numArches = numPosts;
    const archSegments = 50;

    for (let i = 0; i < numPosts; i++) {
        let x = -(params.width + 0.8) / 2 + (i * (params.width + 0.8)) / (numPosts - 1);
        let archCurve = new THREE.CatmullRomCurve3([
            new THREE.Vector3(x, params.height, -params.depth / 2),
            new THREE.Vector3(x, params.height + params.depth * 0.225, -params.depth / 4),
            new THREE.Vector3(x, params.height + params.depth * 0.3, 0),
            new THREE.Vector3(x, params.height + params.depth * 0.225, params.depth / 4),
            new THREE.Vector3(x, params.height, params.depth / 2)
        ], false);

        let smoothPoints = archCurve.getPoints(archSegments).map(p => new THREE.Vector3(p.x * 1.025, p.y - params.height + 0.05, p.z));
        roofPoints.push(...smoothPoints);

        canopy.add(new THREE.Mesh(new THREE.TubeGeometry(archCurve, 50, 0.1, 8, false), metalMaterial));
    }

    const roofGeometry = new THREE.BufferGeometry();
    const vertices = [];
    const indices = [];
    const rowLength = archSegments + 1;

    for (let i = 0; i < numArches; i++) {
        for (let j = 0; j < rowLength - 1; j++) {
            let index1 = i * rowLength + j;
            let index2 = (i + 1) * rowLength + j;
            let index3 = i * rowLength + j + 1;
            let index4 = (i + 1) * rowLength + j + 1;

            if (roofPoints[index1] && roofPoints[index2] && roofPoints[index3] && roofPoints[index4]) {
                vertices.push(
                    roofPoints[index1].x, roofPoints[index1].y, roofPoints[index1].z,
                    roofPoints[index2].x, roofPoints[index2].y, roofPoints[index2].z,
                    roofPoints[index3].x, roofPoints[index3].y, roofPoints[index3].z,
                    roofPoints[index4].x, roofPoints[index4].y, roofPoints[index4].z
                );

                let baseIndex = (i * (rowLength - 1) + j) * 4;
                indices.push(
                    baseIndex, baseIndex + 1, baseIndex + 2,
                    baseIndex + 2, baseIndex + 1, baseIndex + 3
                );
            }
        }
    }

    roofGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(vertices), 3));
    roofGeometry.setIndex(indices);
    roofGeometry.computeVertexNormals();

    const roofMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x3399ff, 
        side: THREE.DoubleSide, 
        transparent: true, 
        opacity: 0.5 
    });

    const roof = new THREE.Mesh(roofGeometry, roofMaterial);
    roof.position.y = params.height + 0.1;
    canopy.add(roof);
}

createCanopy();

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    document.getElementById('camera-pos').textContent = 
        `x: ${camera.position.x.toFixed(2)}, y: ${camera.position.y.toFixed(2)}, z: ${camera.position.z.toFixed(2)}`;
    renderer.render(scene, camera);
}

animate();

window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
});

function updateCanopy() {
    params.depth = parseFloat(document.getElementById('input-width').value);
    params.width = parseFloat(document.getElementById('input-depth').value);
    params.height = parseFloat(document.getElementById('input-height').value);
    params.postThickness = parseFloat(document.getElementById('input-post-thickness').value);
    params.frameType = document.getElementById('input-frame-type').value;
    createCanopy();
}

document.getElementById('input-width').oninput = updateCanopy;
document.getElementById('input-depth').oninput = updateCanopy;
document.getElementById('input-height').oninput = updateCanopy;
document.getElementById('input-post-thickness').oninput = updateCanopy;
document.getElementById('input-frame-type').onchange = updateCanopy;
